1. Requirements: you have to know how to set up betacraft
2. additional skills: adding mods to betacraft

0.1 create new instance in betacraft call it ZETA
0.2 start it and create new world than close it
0.3 search %appdata% roaming -> .betacraft and look for folder called 'versions'
0.4 copy 1.7.3 jar or (default jar) onto your desktop and rename it
0.5 open it with 7zip(WARNING! remember to remove METAINF) and also rebfZeta.jar than drag to it all class files from rebfZeta(or simply ctrl+A, ctrl+C, ctrl+V) 
0.7 than paste that newly created jar to mods folder
0.7.1 mod_sound need to be pasted to resources-> newsound(If done incorrectly sound from some mobs will be mute)
0.8 open betacraft again and 'select version' choose your jar
1.0 HAVE FUN!

